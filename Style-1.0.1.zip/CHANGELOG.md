# Changelog
All notable changes to this project will be documented in this file.

## 1.0.1 [2024-04-10]
- Change support URL & Auther email
## Fixed & Improvements
- Improve Site Speed
- Fix minor bugs

## 1.0.0 [2023-08-03]
- Initial Release
